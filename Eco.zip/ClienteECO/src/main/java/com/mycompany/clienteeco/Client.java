package com.mycompany.clienteeco;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Scanner;


/**
 *
 * @author yulian
 */
public class Client {
    public static void main(String[] args) throws IOException{
         final int portServer =5001;
         byte[] buffer = new byte[1024];
         
         Scanner readText = new Scanner(System.in);
         String clientMessage = new String();
         String ip = new String();
         System.out.println("Ingrese ip del servidor: ");
         ip = readText.nextLine();
        try{
            InetAddress ipServer = InetAddress.getByName(ip);
            DatagramSocket socketUDP = new DatagramSocket();
            do{
            System.out.println("Ingresa el texto: ");
            clientMessage = readText.nextLine();
            buffer = clientMessage.getBytes();
            
            DatagramPacket requestToServer = new DatagramPacket(buffer, buffer.length, ipServer, portServer);
            socketUDP.send(requestToServer);
            
            DatagramPacket responseToClient = new DatagramPacket(buffer, buffer.length);
            socketUDP.receive(responseToClient);
            
            String serverMessage = new String(responseToClient.getData());
            System.out.println(serverMessage);
                
            }while(!clientMessage.isEmpty());

            /*readText.close();
            socketUDP.close();*/
            
         }catch(SocketException ex){
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
}
