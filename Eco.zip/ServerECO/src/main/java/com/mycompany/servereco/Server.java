package com.mycompany.servereco;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author yulian
 */
public class Server {
    public static void main(String[] args) throws IOException {
        final int port = 5001;
        byte[] buffer = new byte[1024];

        try {
            System.out.println("Iniciando Servidor en el puerto: " + port);
            DatagramSocket UDPsocket = new DatagramSocket(port);
            while (true) {

                DatagramPacket requestOfClient = new DatagramPacket(buffer, buffer.length);

                UDPsocket.receive(requestOfClient);

                String clientMessageRequest = new String(requestOfClient.getData());
                System.out.println("Mensaje del Cliente UDP: " + clientMessageRequest);

                int portClient = requestOfClient.getPort();
                InetAddress ipClient = requestOfClient.getAddress();

                @SuppressWarnings("UnusedAssignment")
                String serverMessageResponse = new String();
                serverMessageResponse = clientMessageRequest;
                buffer = serverMessageResponse.getBytes();

                DatagramPacket responseToClient = new DatagramPacket(buffer, buffer.length, ipClient, portClient);
                UDPsocket.send(responseToClient);

                buffer = null;
                buffer = new byte[1024];
            }
        } catch (SocketException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
